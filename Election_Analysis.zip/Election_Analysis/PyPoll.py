#Open the data we need to retrieve 

#1.The total number of votes

#2.Complete list of candidates who received votes

#3.The percentage of votes each candidate won

#4.The total number of votes each candidate won

#5.The winner of the election based on popular vote

